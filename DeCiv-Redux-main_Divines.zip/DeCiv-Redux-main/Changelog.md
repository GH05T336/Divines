## 5.1.0 - 04/27/2022

Moddable victory now implemented

New traits for water units

Removed traces of deprecated terrains

## 5.0.2 - 04/02/2022

Helicopter units can now move and attack on water just like on land

## 5.0.1 - 03/27/2022

added Space Station Wreckage (art by Indonesian Gentleman) and Salvage Space Station

new Tech icons and general art improvement

by HaneulCheong:
* big cleanup of all files

## 5.0.0 - 03/26/2022

updated all uniques

changed over terrains - replaced Snow, Plains, and Grassland with Permafrost, Badlands, and Wasteland

replaced Wheat with Grain, added Groundwater back in

nerfed Armor Production Line

Barbarians can now give up to 1000 xp<br>
edit: turned down to 150 xp

began process of adding more naval units

added Oceanography tech (almost forgot this one!)

## 4.2.1 - 03/23/2022

removed all negative modifiers to earning Great General

fixed bugs in Forage promotion and Prison farm improvement

made Ranger's abilities inheritable

by HaneulCheong:
* reconfigure policy tree
* change coastal buildings to work coast
* fix Polytheism's image

by Archduque-Pancake:
* update Spanish translation

## 4.2.0 - 03/20/2022

added new difficulty levels

made special promotions more accessible

added Forward Observer unit