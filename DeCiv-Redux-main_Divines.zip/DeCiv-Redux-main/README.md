# DeCiv-Redux

DeCiv Redux 6.0.1<br>
6 July 2022

[Join our Discord server!](https://discord.gg/SsWZ3w8UFJ)<br>
[Visit our wiki!](https://github.com/SpacedOutChicken/DeCiv-Redux/wiki)

DeCiv, made by [9kgsofrice](https://github.com/9kgsofrice/DeCiv/), brought back from the dead by SpacedOutChicken

Building a civilization is hard. Rebuilding one might be even harder. But what choice do you have? The world has ended, and you are still alive, at least for now. But life's a lot harder than it used to be. Food is scarce, potable water is more precious than gold, and there's never enough power to keep all the lights on. In this barren, used-up wasteland, can you succeed where the nations of the past have failed? Can you build a new civilization that will pass the test of time?

This is a huge mod, so keeping it updated is a perpetual work in progress. If you find a bug, let me know!
